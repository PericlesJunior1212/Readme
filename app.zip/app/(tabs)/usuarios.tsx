import { Image, StyleSheet, Platform, Text, FlatList, View, Pressable } from 'react-native';
import { Usuarios } from '@/constants/Usuarios';
import { Link } from 'expo-router';
import { ScrollView } from 'react-native-gesture-handler';
import { useEffect, useState } from 'react';

type User = {
  id: number;
  nome: string;
  nome_grupo: string;
};


export default function HomeScreen() {
   const [users, setUsers] = useState<User[] | null>(null);
  useEffect(() => {

    const getUsuarios = async () => {
      try {
        const response = await fetch('http://localhost/PJ/usuarios');
        // const response = await fetch('https://novo.mobi-rio.rio.br/get-avisos');
        const data = await response.json();
        setUsers(data.usuarios);
        console.error('users:', data.usuarios);
      } catch (error) {
        console.error('Erro ao buscar usuários:', error);
      }
    };

    getUsuarios();
  }, []);
  return (

<ScrollView style={{backgroundColor: 'gray'}}>
<Text style={styles.title}>Lista de Usuários</Text>
      <FlatList
        data={users}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <Text> Id: {item.id}</Text>
            <Text> Nome: {item.nome}</Text>
            <Text> Nome do Grupo: {item.nome_grupo}</Text>
            </View>
        )}
      /></ScrollView>
    )}


    const styles = StyleSheet.create({
 
        container: {
          flex: 1,
          padding: 20,
          backgroundColor: '#f8f8f8',
        },
        card: {
          backgroundColor: 'White',
          padding: 15,
          marginVertical: 8,
          borderRadius: 10,
        },
        title: {
          fontSize: 22,
          fontWeight: 'bold',
          marginBottom: 10,
        
        }
      });